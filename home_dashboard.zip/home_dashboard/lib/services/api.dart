import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/sensor_data.dart';
import 'auth_service.dart';

class ApiService {
  final AuthService auth;

  ApiService(this.auth);

  static const String baseUrl = "http://localhost:5000"; // web

  Future<SensorData> fetchData() async {
    final token = await auth.getToken();
    final res = await http.get(
      Uri.parse("$baseUrl/data"),
      headers: {
        "Content-Type": "application/json",
        if (token != null) "Authorization": "Bearer $token",
      },
    );

    if (res.statusCode != 200) throw Exception("Failed to load data");
    return SensorData.fromJson(jsonDecode(res.body));
  }

  Future<void> controlDevice(String device, dynamic state) async {
    final token = await auth.getToken();
    final res = await http.post(
      Uri.parse("$baseUrl/control"),
      headers: {
        "Content-Type": "application/json",
        if (token != null) "Authorization": "Bearer $token",
      },
      body: jsonEncode({"device": device, "state": state}),
    );

    if (res.statusCode != 200) {
      throw Exception("Control failed: ${res.body}");
    }
  }
}
