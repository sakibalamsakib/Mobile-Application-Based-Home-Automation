import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class AuthService {
  static const String baseUrl = "http://localhost:5000"; // web
  // For Android emulator: http://10.0.2.2:5000
  // For real phone: http://YOUR_PC_IP:5000

  Future<String?> getToken() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString("token");
  }

  Future<void> saveToken(String token, {bool remember = true}) async {
    final prefs = await SharedPreferences.getInstance();
    if (remember) {
      await prefs.setString("token", token);
    } else {
      // If user doesn't want remember, store for session-ish:
      await prefs.setString("token", token);
    }
  }

  Future<void> logout() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove("token");
  }

  Future<String> register(String email, String password) async {
    final res = await http.post(
      Uri.parse("$baseUrl/register"),
      headers: {"Content-Type": "application/json"},
      body: jsonEncode({"email": email, "password": password}),
    );

    final data = jsonDecode(res.body);
    if (res.statusCode != 200) {
      throw Exception(data["error"] ?? "Register failed");
    }
    return data["token"];
  }

  Future<String> login(String email, String password) async {
    final res = await http.post(
      Uri.parse("$baseUrl/login"),
      headers: {"Content-Type": "application/json"},
      body: jsonEncode({"email": email, "password": password}),
    );

    final data = jsonDecode(res.body);
    if (res.statusCode != 200) {
      throw Exception(data["error"] ?? "Login failed");
    }
    return data["token"];
  }
}
