class SensorData {
  final List<dynamic> temp, hum, soil, gas, light;
  final List<dynamic> fan, pump, led1, led2, window;
  final List<dynamic> time;

  SensorData({
    required this.temp,
    required this.hum,
    required this.soil,
    required this.gas,
    required this.light,
    required this.fan,
    required this.pump,
    required this.led1,
    required this.led2,
    required this.window,
    required this.time,
  });

  factory SensorData.fromJson(Map<String, dynamic> json) {
    List<dynamic> list(String k) => (json[k] as List?) ?? [];
    return SensorData(
      temp: list("temp"),
      hum: list("hum"),
      soil: list("soil"),
      gas: list("gas"),
      light: list("light"),
      fan: list("fan"),
      pump: list("pump"),
      led1: list("led1"),
      led2: list("led2"),
      window: list("window"),
      time: list("time"),
    );
  }

  dynamic last(List<dynamic> x) => x.isEmpty ? null : x.last;
}
