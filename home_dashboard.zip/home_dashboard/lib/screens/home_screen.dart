import 'dart:async';
import 'package:flutter/material.dart';
import '../services/auth_service.dart';
import '../services/api.dart';
import '../models/sensor_data.dart';
import '../widgets/sensor_tile.dart';
import 'trends_screen.dart';
import 'control_screen.dart';
import 'login_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final auth = AuthService();
  late final api = ApiService(auth);

  Timer? t;
  SensorData? data;
  String? error;

  @override
  void initState() {
    super.initState();
    fetch();
    t = Timer.periodic(const Duration(seconds: 3), (_) => fetch());
  }

  @override
  void dispose() {
    t?.cancel();
    super.dispose();
  }

  Future<void> fetch() async {
    try {
      final d = await api.fetchData();
      if (!mounted) return;
      setState(() {
        data = d;
        error = null;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => error = e.toString());
    }
  }

  String show(dynamic v) => v == null ? "-" : "$v";

  @override
  Widget build(BuildContext context) {
    final d = data;
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(
          title: const Text("Smart Home"),
          actions: [
            TextButton.icon(
              onPressed: () async {
                await auth.logout();
                if (!mounted) return;
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (_) => const LoginScreen()),
                );
              },
              icon: const Icon(Icons.logout),
              label: const Text("Logout"),
            ),
          ],
          bottom: const TabBar(
            tabs: [
              Tab(text: "Real-Time"),
              Tab(text: "Trends"),
              Tab(text: "Control"),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            // -------- Real-Time --------
            Padding(
              padding: const EdgeInsets.all(12),
              child: error != null
                  ? Center(child: Text(error!))
                  : ListView(
                      children: [
                        const Text(
                          "Real-Time Sensor Data",
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        const SizedBox(height: 10),

                        SensorTile(
                          icon: Icons.thermostat,
                          title: "Temperature",
                          valueText: "${show(d?.last(d?.temp ?? []))} °C",
                        ),
                        SensorTile(
                          icon: Icons.water_drop,
                          title: "Humidity",
                          valueText: "${show(d?.last(d?.hum ?? []))} %",
                        ),
                        SensorTile(
                          icon: Icons.grass,
                          title: "Soil Dryness",
                          valueText: "${show(d?.last(d?.soil ?? []))} %",
                        ),
                        SensorTile(
                          icon: Icons.science,
                          title: "Gas Level",
                          valueText: "${show(d?.last(d?.gas ?? []))} ppm",
                        ),
                        SensorTile(
                          icon: Icons.light_mode,
                          title: "Light",
                          valueText: "${show(d?.last(d?.light ?? []))} lux",
                        ),
                      ],
                    ),
            ),

            // -------- Trends --------
            TrendsScreen(data: data),

            // -------- Control --------
            ControlScreen(api: api, data: data),
          ],
        ),
      ),
    );
  }
}
