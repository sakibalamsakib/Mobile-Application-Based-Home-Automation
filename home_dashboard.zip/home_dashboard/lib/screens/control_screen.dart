import 'package:flutter/material.dart';
import '../models/sensor_data.dart';
import '../services/api.dart';

class ControlScreen extends StatefulWidget {
  final ApiService api;
  final SensorData? data;

  const ControlScreen({super.key, required this.api, required this.data});

  @override
  State<ControlScreen> createState() => _ControlScreenState();
}

class _ControlScreenState extends State<ControlScreen> {
  String? msg;

  Future<void> toggle(String device, bool on) async {
    try {
      await widget.api.controlDevice(device, on ? 1 : 0);
      setState(() => msg = "$device => ${on ? "ON" : "OFF"}");
    } catch (e) {
      setState(() => msg = e.toString());
    }
  }

  bool isOn(dynamic v) {
    if (v == null) return false;
    if (v is num) return v != 0;
    final s = "$v".toLowerCase();
    return s == "on" || s == "1" || s == "true";
  }

  Widget controlCard(String title, String device, bool current) {
    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.power_settings_new, size: 30),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    title,
                    style: const TextStyle(fontWeight: FontWeight.w700),
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 12,
                    vertical: 6,
                  ),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    color: current
                        ? Colors.green.withOpacity(0.15)
                        : Colors.grey.withOpacity(0.15),
                  ),
                  child: Text(
                    current ? "ON" : "OFF",
                    style: const TextStyle(fontWeight: FontWeight.w700),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              height: 44,
              child: ElevatedButton(
                onPressed: () => toggle(device, !current),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.green,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                child: Text(
                  current ? "Turn OFF" : "Turn ON",
                  style: const TextStyle(color: Colors.white),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final d = widget.data;
    final fan = isOn(d?.last(d?.fan ?? []));
    final pump = isOn(d?.last(d?.pump ?? []));
    final led1 = isOn(d?.last(d?.led1 ?? []));
    final led2 = isOn(d?.last(d?.led2 ?? []));
    final window = isOn(d?.last(d?.window ?? []));

    return Padding(
      padding: const EdgeInsets.all(12),
      child: ListView(
        children: [
          const Text(
            "Actuator Status & Control",
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
          ),
          const SizedBox(height: 10),

          controlCard("Fan", "fan", fan),
          controlCard("Pump", "pump", pump),
          controlCard("LED 1", "led1", led1),
          controlCard("LED 2", "led2", led2),
          controlCard("Window", "window", window),

          if (msg != null) ...[
            const SizedBox(height: 10),
            Text(msg!, style: const TextStyle(color: Colors.blue)),
          ],
        ],
      ),
    );
  }
}
