import 'package:flutter/material.dart';
import '../models/sensor_data.dart';
import '../widgets/sensor_chart_card.dart';

class TrendsScreen extends StatelessWidget {
  final SensorData? data;
  const TrendsScreen({super.key, required this.data});

  List<double> lastNumbers(List<dynamic> list, int n) {
    final sliced = list.length <= n ? list : list.sublist(list.length - n);
    return sliced
        .map((e) => (e is num) ? e.toDouble() : double.tryParse("$e") ?? 0.0)
        .toList();
  }

  @override
  Widget build(BuildContext context) {
    final d = data;
    if (d == null) return const Center(child: Text("No data yet..."));

    return Padding(
      padding: const EdgeInsets.all(12),
      child: ListView(
        children: [
          const Text(
            "Sensor Trends",
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
          ),
          const SizedBox(height: 10),

          SensorChartCard(
            title: "Temperature Trend",
            values: lastNumbers(d.temp, 10),
          ),
          const SizedBox(height: 12),
          SensorChartCard(
            title: "Humidity Trend",
            values: lastNumbers(d.hum, 10),
          ),
          const SizedBox(height: 12),
          SensorChartCard(
            title: "Soil Dryness Trend",
            values: lastNumbers(d.soil, 10),
          ),
        ],
      ),
    );
  }
}
